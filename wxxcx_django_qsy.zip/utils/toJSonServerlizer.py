# from rest_framework import serializers  # 这就是express中的serializers
# # 序列化的表格也要导入进来
# from wxdjqsy.models import lbt
#
#
# # 序列化获取数据库中的数据
# class PvPaneltoJSON(serializers.ModelSerializer):
#     class Meta:
#         model = lbt  # 数据表
#         fields = '__all__'    #返回所有字段
#         # fields = ["ipaddr"]   #自定义返回字段

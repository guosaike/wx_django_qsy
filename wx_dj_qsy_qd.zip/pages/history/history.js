var app = getApp()
Page({
    data: {
        analysis: [],
        video_ad: "",
    },
    copyBtn(a) {
        wx.setClipboardData({
            data: a.target.dataset.kefu,
            success: function(a) {
                wx.showToast({
                    title: "复制成功",
                    icon: "none",
                    mask: "true"
                });
            }
        });
    },
    clear_record() {
        this.setData({
            analysis: []
        }), wx.removeStorageSync("analysis");
    },
    onLoad(a) {
        this.gg_ad()
        let e = wx.getStorageSync("analysis");
        this.setData({
            analysis: e
        });
    },
    gg_ad() {
      let a = this;
      wx.request({
        url: app.globalData.default + '/api/gg_ad/',
            header: {
                "content-type": "application/json"
            },
            success: (res) =>{
              a.setData({
                video_ad: res.data.llz[1]
              })
            },
      })
    },
    adLoad() {
      // console.log('视频广告 广告加载成功')
    },
    adError(err) {
      // console.error('视频广告 广告加载失败', err)
    },
    adClose() {
      // console.log('视频广告 广告关闭')
    },
    onReady() {},
    onShow() {},
    onHide() {},
    onUnload() {},
    onPullDownRefresh() {},
    onReachBottom() {},
    onShareAppMessage() {}
});